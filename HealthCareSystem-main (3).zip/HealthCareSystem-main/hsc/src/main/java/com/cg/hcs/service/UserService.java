package com.cg.hcs.service;

import com.cg.hcs.entity.User;

public interface UserService {
    public User addUser(User user);
}
